# app.py
import streamlit as st
import PyPDF2
import faiss
import numpy as np
import requests
from sentence_transformers import SentenceTransformer

# ---------------------------
# Groq API settings
# ---------------------------

GROQ_API_KEY = "None"  
GROQ_CHAT_MODEL = "llama-3.3-70b-versatile"


# ---------------------------
# Embedding model (local)
# ---------------------------
embedder = SentenceTransformer("all-MiniLM-L6-v2")

def local_embedding(texts):
    return embedder.encode(texts, convert_to_numpy=True).tolist()


# ---------------------------
# Groq Chat
# ---------------------------
def groq_chat(messages, max_tokens=300):
    url = "https://api.groq.com/openai/v1/chat/completions"
    headers = {"Authorization": f"Bearer {GROQ_API_KEY}", "Content-Type": "application/json"}
    payload = {"model": GROQ_CHAT_MODEL, "messages": messages, "max_tokens": max_tokens}
    resp = requests.post(url, headers=headers, json=payload)
    return resp.json()

# ---------------------------
# Streamlit UI
# ---------------------------
st.set_page_config(page_title="PDF Chatbot with Groq", layout="wide")
st.title("Q&A with Your Docs")

# Sidebar
st.sidebar.header("⚙️ Settings")

uploaded_files = st.sidebar.file_uploader("Upload PDF(s)", type=["pdf"], accept_multiple_files=True)

# Session state
if "vector_index" not in st.session_state:
    st.session_state.vector_index = None
    st.session_state.text_chunks = []
if "chat_history" not in st.session_state:
    st.session_state.chat_history = []

# Process PDFs
if uploaded_files:
    with st.spinner("📚 Processing your PDF(s)..."):
        all_chunks = []
        for uploaded_file in uploaded_files:
            pdf_reader = PyPDF2.PdfReader(uploaded_file)
            text = ""
            for page in pdf_reader.pages:
                text += page.extract_text() or ""
            # Split into chunks
            chunks = [text[i:i+500] for i in range(0, len(text), 500)]
            all_chunks.extend(chunks)

        # Use local embeddings
        embeddings = local_embedding(all_chunks)
        dim = len(embeddings[0])
        index = faiss.IndexFlatL2(dim)
        index.add(np.array(embeddings).astype("float32"))

        st.session_state.vector_index = index
        st.session_state.text_chunks = all_chunks

    st.sidebar.success(f"✅ {len(all_chunks)} chunks stored in memory.")

# Layout: Two columns
col1, col2 = st.columns([1, 2])

with col1:
    st.subheader("Uploaded PDFs")
    if uploaded_files:
        for f in uploaded_files:
            st.write(f"📄 {f.name}")
    else:
        st.write("No PDF uploaded yet.")

with col2:
    st.subheader("Q&A with Your AI")

    query = st.text_input("Ask a question:")
    if query and st.session_state.vector_index:
        # Embed query
        q_emb = np.array(local_embedding([query])).astype("float32")
        # Search top 3
        D, I = st.session_state.vector_index.search(q_emb, k=3)
        context = "\n".join([st.session_state.text_chunks[i] for i in I[0]])

        messages = [
            {"role": "system", "content": "Use the context to answer the user's question accurately."},
            {"role": "user", "content": f"Context:\n{context}\n\nQuestion: {query}"}
        ]

        with st.spinner("🤖 Thinking..."):
            resp = groq_chat(messages)
            try:
                answer = resp['choices'][0]['message']['content']
            except:
                answer = str(resp)

        # Save chat history
        st.session_state.chat_history.append({"question": query, "answer": answer})

    # Display chat history
    if st.session_state.chat_history:
        for chat in reversed(st.session_state.chat_history):
            st.markdown(f"**🧑 You:** {chat['question']}")
            st.markdown(f"**🤖 AI:** {chat['answer']}")
